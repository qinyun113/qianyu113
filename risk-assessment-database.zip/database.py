from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from datetime import datetime
import uuid

db = SQLAlchemy()

# 风险数据模型
class Risk(db.Model):
    __tablename__ = 'risks'
    
    id = db.Column(db.String(50), primary_key=True, default=lambda: f"R-{uuid.uuid4().hex[:8]}")
    project_name = db.Column(db.String(100), nullable=False)
    risk_level = db.Column(db.String(20), nullable=False)
    risk_type = db.Column(db.String(50))
    probability = db.Column(db.String(20))
    impact = db.Column(db.String(20))
    risk_score = db.Column(db.Float)
    status = db.Column(db.String(20))
    create_time = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 定义与Project的关系
    project_id = db.Column(db.String(50), db.ForeignKey('projects.id'))
    project = db.relationship('Project', back_populates='risks')
    
    # 定义与RiskAssessment的关系
    assessments = db.relationship('RiskAssessment', back_populates='risk', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'project_name': self.project_name,
            'risk_level': self.risk_level,
            'risk_type': self.risk_type,
            'probability': self.probability,
            'impact': self.impact,
            'risk_score': self.risk_score,
            'status': self.status,
            'create_time': self.create_time.strftime('%Y-%m-%d')
        }

# 项目模型
class Project(db.Model):
    __tablename__ = 'projects'
    
    id = db.Column(db.String(50), primary_key=True, default=lambda: f"P-{uuid.uuid4().hex[:8]}")
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.Text)
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    status = db.Column(db.String(20))
    
    # 定义与Risk的关系
    risks = db.relationship('Risk', back_populates='project', cascade='all, delete-orphan')
    
    # 定义与UploadHistory的关系
    uploads = db.relationship('UploadHistory', back_populates='project', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'start_date': self.start_date.strftime('%Y-%m-%d') if self.start_date else None,
            'end_date': self.end_date.strftime('%Y-%m-%d') if self.end_date else None,
            'status': self.status,
            'risk_count': len(self.risks)
        }

# 上传历史模型
class UploadHistory(db.Model):
    __tablename__ = 'upload_history'
    
    id = db.Column(db.String(50), primary_key=True, default=lambda: f"U-{uuid.uuid4().hex[:8]}")
    filename = db.Column(db.String(200), nullable=False)
    original_filename = db.Column(db.String(200), nullable=False)
    data_type = db.Column(db.String(50))
    upload_time = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20))
    size = db.Column(db.Integer)
    file_path = db.Column(db.String(200))
    
    # 定义与Project的关系
    project_id = db.Column(db.String(50), db.ForeignKey('projects.id'))
    project = db.relationship('Project', back_populates='uploads')
    
    def to_dict(self):
        size_str = f"{self.size / 1024:.1f} KB" if self.size < 1024*1024 else f"{self.size / (1024*1024):.1f} MB"
        return {
            'id': self.id,
            'filename': self.filename,
            'original_filename': self.original_filename,
            'project_name': self.project.name if self.project else None,
            'data_type': self.data_type,
            'upload_time': self.upload_time.strftime('%Y-%m-%d %H:%M:%S'),
            'status': self.status,
            'size': size_str,
            'file_path': self.file_path
        }

# 风险评估模型
class RiskAssessment(db.Model):
    __tablename__ = 'risk_assessments'
    
    id = db.Column(db.String(50), primary_key=True, default=lambda: f"A-{uuid.uuid4().hex[:8]}")
    risk_id = db.Column(db.String(50), db.ForeignKey('risks.id'))
    assessment_time = db.Column(db.DateTime, default=datetime.utcnow)
    assessment_method = db.Column(db.String(50))
    confidence_level = db.Column(db.Float)
    results = db.Column(db.JSON)
    
    risk = db.relationship('Risk', back_populates='assessments')
    
    def to_dict(self):
        return {
            'id': self.id,
            'risk_id': self.risk_id,
            'assessment_time': self.assessment_time.strftime('%Y-%m-%d %H:%M:%S'),
            'assessment_method': self.assessment_method,
            'confidence_level': self.confidence_level,
            'results': self.results
        }

# 预测数据模型
class Prediction(db.Model):
    __tablename__ = 'predictions'
    
    id = db.Column(db.String(50), primary_key=True, default=lambda: f"PRED-{uuid.uuid4().hex[:8]}")
    project_id = db.Column(db.String(50), db.ForeignKey('projects.id'))
    prediction_time = db.Column(db.DateTime, default=datetime.utcnow)
    algorithm = db.Column(db.String(50))
    period = db.Column(db.Integer)
    accuracy = db.Column(db.Float)
    history_data = db.Column(db.JSON)
    prediction_data = db.Column(db.JSON)
    risk_assessment = db.Column(db.JSON)
    
    project = db.relationship('Project', backref='predictions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'project_id': self.project_id,
            'prediction_time': self.prediction_time.strftime('%Y-%m-%d %H:%M:%S'),
            'algorithm': self.algorithm,
            'period': self.period,
            'accuracy': self.accuracy,
            'history_data': self.history_data,
            'prediction_data': self.prediction_data,
            'risk_assessment': self.risk_assessment
        }

# 数据库操作类
class DatabaseManager:
    @staticmethod
    def init_app(app, database_uri='sqlite:///risk_assessment.db'):
        app.config['SQLALCHEMY_DATABASE_URI'] = database_uri
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        db.init_app(app)
        with app.app_context():
            db.create_all()
    
    @staticmethod
    def add_risk(data, project_id=None):
        risk = Risk(
            project_name=data.get('project_name'),
            risk_level=data.get('risk_level'),
            risk_type=data.get('risk_type'),
            probability=data.get('probability'),
            impact=data.get('impact'),
            risk_score=data.get('risk_score'),
            status=data.get('status'),
            project_id=project_id
        )
        db.session.add(risk)
        db.session.commit()
        return risk
    
    @staticmethod
    def get_risks(project_id=None, filters=None, sort_by='create_time', sort_order='desc', page=1, per_page=10):
        query = Risk.query
        
        if project_id:
            query = query.filter_by(project_id=project_id)
        
        if filters:
            if 'risk_level' in filters:
                query = query.filter(Risk.risk_level.in_(filters['risk_level']))
            if 'risk_type' in filters:
                query = query.filter(Risk.risk_type.in_(filters['risk_type']))
            if 'status' in filters:
                query = query.filter(Risk.status.in_(filters['status']))
        
        # 排序
        if sort_order == 'desc':
            query = query.order_by(getattr(Risk, sort_by).desc())
        else:
            query = query.order_by(getattr(Risk, sort_by).asc())
        
        # 分页
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        return pagination.items, pagination.total
    
    @staticmethod
    def get_risk_stats():
        total_risks = Risk.query.count()
        high_risk = Risk.query.filter_by(risk_level='高风险').count()
        medium_risk = Risk.query.filter_by(risk_level='中风险').count()
        low_risk = Risk.query.filter_by(risk_level='低风险').count()
        
        # 计算风险趋势数据（最近7天）
        trend_data = {
            'labels': [],
            'risk_index': [],
            'high_risk_count': []
        }
        
        for i in range(7, 0, -1):
            date = (datetime.now() - pd.Timedelta(days=i)).strftime('%Y-%m-%d')
            trend_data['labels'].append(date)
            
            # 模拟风险指数（实际应用中应从历史数据计算）
            trend_data['risk_index'].append(50 + np.random.randint(10, 40))
            
            # 模拟高风险数量
            trend_data['high_risk_count'].append(np.random.randint(5, 15))
        
        # 计算风险类型分布
        risk_types = db.session.query(Risk.risk_type, func.count(Risk.id)).group_by(Risk.risk_type).all()
        risk_types_dict = {row[0]: row[1] for row in risk_types}
        
        return {
            'total_risks': total_risks,
            'high_risk': high_risk,
            'medium_risk': medium_risk,
            'low_risk': low_risk,
            'risk_trend': trend_data,
            'risk_types': risk_types_dict
        }
    
    @staticmethod
    def add_project(data):
        project = Project(
            name=data.get('name'),
            description=data.get('description'),
            start_date=data.get('start_date'),
            end_date=data.get('end_date'),
            status=data.get('status', '进行中')
        )
        db.session.add(project)
        db.session.commit()
        return project
    
    @staticmethod
    def get_projects():
        return Project.query.all()
    
    @staticmethod
    def add_upload_history(data, project_id=None):
        upload = UploadHistory(
            filename=data.get('filename'),
            original_filename=data.get('original_filename'),
            data_type=data.get('data_type'),
            status=data.get('status', '成功'),
            size=data.get('size'),
            file_path=data.get('file_path'),
            project_id=project_id
        )
        db.session.add(upload)
        db.session.commit()
        return upload
    
    @staticmethod
    def get_upload_history(project_id=None, page=1, per_page=10):
        query = UploadHistory.query
        
        if project_id:
            query = query.filter_by(project_id=project_id)
        
        # 按上传时间倒序
        query = query.order_by(UploadHistory.upload_time.desc())
        
        # 分页
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        return pagination.items, pagination.total
    
    @staticmethod
    def add_prediction(data, project_id):
        prediction = Prediction(
            project_id=project_id,
            algorithm=data.get('algorithm'),
            period=data.get('period'),
            accuracy=data.get('accuracy'),
            history_data=data.get('history_data'),
            prediction_data=data.get('prediction_data'),
            risk_assessment=data.get('risk_assessment')
        )
        db.session.add(prediction)
        db.session.commit()
        return prediction
    
    @staticmethod
    def get_predictions(project_id, page=1, per_page=10):
        query = Prediction.query.filter_by(project_id=project_id)
        query = query.order_by(Prediction.prediction_time.desc())
        
        pagination = query.paginate(page=page, per_page=per_page, error_out=False)
        return pagination.items, pagination.total    