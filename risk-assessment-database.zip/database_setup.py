from database import db, Project, Risk, UploadHistory, DatabaseManager
from flask import Flask
import pandas as pd
from datetime import datetime, timedelta
import numpy as np

# 创建Flask应用
app = Flask(__name__)
DatabaseManager.init_app(app, 'sqlite:///risk_assessment.db')

# 添加示例数据
def add_sample_data():
    with app.app_context():
        # 检查是否已有数据
        if Project.query.first():
            print("已有数据，跳过初始化")
            return
        
        # 创建项目
        project1 = Project(
            name="市场拓展项目",
            description="开拓新市场的战略计划",
            start_date=datetime(2023, 10, 1),
            end_date=datetime(2024, 9, 30),
            status="进行中"
        )
        
        project2 = Project(
            name="新产品研发",
            description="开发新一代产品的研究项目",
            start_date=datetime(2023, 12, 15),
            end_date=datetime(2024, 11, 15),
            status="计划中"
        )
        
        db.session.add_all([project1, project2])
        db.session.commit()
        
        # 创建风险数据
        risks = [
            {
                "project_id": project1.id,
                "project_name": project1.name,
                "risk_level": "高风险",
                "risk_type": "市场风险",
                "probability": "80%",
                "impact": "严重",
                "risk_score": 78.5,
                "status": "处理中",
                "create_time": datetime.now() - timedelta(days=5)
            },
            {
                "project_id": project1.id,
                "project_name": project1.name,
                "risk_level": "中风险",
                "risk_type": "竞争风险",
                "probability": "60%",
                "impact": "中等",
                "risk_score": 58.2,
                "status": "未处理",
                "create_time": datetime.now() - timedelta(days=3)
            },
            {
                "project_id": project2.id,
                "project_name": project2.name,
                "risk_level": "高风险",
                "risk_type": "技术风险",
                "probability": "75%",
                "impact": "严重",
                "risk_score": 82.3,
                "status": "处理中",
                "create_time": datetime.now() - timedelta(days=4)
            },
            {
                "project_id": project2.id,
                "project_name": project2.name,
                "risk_level": "低风险",
                "risk_type": "资源风险",
                "probability": "30%",
                "impact": "轻微",
                "risk_score": 28.7,
                "status": "已处理",
                "create_time": datetime.now() - timedelta(days=7)
            }
        ]
        
        for risk_data in risks:
            risk = Risk(**risk_data)
            db.session.add(risk)
        
        # 创建上传历史
        uploads = [
            {
                "project_id": project1.id,
                "filename": "risk_data_2023.csv",
                "original_filename": "risk_data_2023.csv",
                "data_type": "历史风险数据",
                "upload_time": datetime.now() - timedelta(days=2),
                "status": "成功",
                "size": 245 * 1024,  # 245KB
                "file_path": "risk_data_2023.csv"
            },
            {
                "project_id": project2.id,
                "filename": "market_data.xlsx",
                "original_filename": "market_data.xlsx",
                "data_type": "市场数据",
                "upload_time": datetime.now() - timedelta(days=3),
                "status": "成功",
                "size": 1.2 * 1024 * 1024,  # 1.2MB
                "file_path": "market_data.xlsx"
            }
        ]
        
        for upload_data in uploads:
            upload = UploadHistory(**upload_data)
            db.session.add(upload)
        
        db.session.commit()
        print("示例数据添加完成")

if __name__ == '__main__':
    add_sample_data()    